

/*
1171742 - Duha Jarrar
1170257 - Yara Zuhd
1171456 - Farah Abu Lebdeh
*/
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

pthread_t p_thread1, p_thread2,p_thread3,p_thread4;// declare thread
pthread_mutex_t seeker_mutex=PTHREAD_MUTEX_INITIALIZER;//1
pthread_mutex_t seeker_mutex1=PTHREAD_MUTEX_INITIALIZER;//1
pthread_mutex_t seeker_mutex2=PTHREAD_MUTEX_INITIALIZER;//1

int tp[4];//tall player
int pCount[4]= {0,0,0,1};//The number of times a player is a seeker
int players[4] = {1,1,1,0};//value 1 =player (3 player) ,value 0=seeker (1 seeker)
int ball[4] = {1,0,0,0};//ball with one player (player 1)
int h,h1;
int x=0;


/////////////////////////////////////////////////////////////

/*A function return index for seeker player*/
int seekerInd()
{
    int i;
    for(i =0; i<4; i++)
    {
        if (players[i]==0)
        {
            break;
        }
    }
    return i;
}

/////////////////////////////////////////////////////////////

/*A function to describe the current situation who is player,seeker,Height,Seeker Conut*/
void printStatus()
{

    for(int i =0; i<4; i++)
    {
        if(players[i]==1)
        {
            printf("\033[0;36m Player #%d , Height =%d , Seeker Conut =%d\n",i+1,tp[i],pCount[i]);
            printf("\033[0m ");
        }
        else if (players[i]==0)
        {
            printf("\033[0;31m Player #%d is seeker , Height =%d , Seeker Conut =%d\n",i+1,tp[i],pCount[i]);
            printf("\033[0m ");
        }
    }
    for(int i =0; i<4; i++)
    {
        if (ball[i]==1)// print ball with any player
        {
            printf("\033[0;33m Ball with Player #%d\n",i+1);
            printf("\033[0m ");
            break;
        }

    }
}

////////////////////////////////////////////////////////////////
int flag=0;
void *game()
{
    pthread_t p_thread;
    /* using pthread_self() get current thread id*/
    p_thread=pthread_self();
//printf("p_thread : %ld \n",p_thread);
    srand(time(0));

    while(pCount[0]<5 && pCount[1]<5 && pCount[2]<5 && pCount[3]<5 )
    {


        int tSeeker= seekerInd();
//printStatus();
        if (pthread_equal(p_thread, p_thread1)) ////////////////////////////////////////////////////////////// player 1
        {

            tSeeker= seekerInd();
            if (tSeeker==0)
            {
                printf("---------------------------------- Player 1 Thread Running now ! ----------------------------------------\n");
                pthread_mutex_lock(&seeker_mutex1);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h1=tp[0]+(rand()%50)+30;

                    printf("Seeker %d jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                else //without jumping
                {
                    h1=tp[0];
                    printf("Seeker %d without jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                pthread_mutex_unlock(&seeker_mutex1);
                printf("*********************************************************************************************************\n");
            }
            else if(ball[0] == 1) // ball with player1
            {
                printf("---------------------------------- Player 1 Thread Running now ! ----------------------------------------\n");
                int toPlayer = rand()%4;
                while(toPlayer == tSeeker || toPlayer == 0)
                {
                    toPlayer = rand()%4;
                }
                pthread_mutex_lock(&seeker_mutex2);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h=tp[0]+(rand()%41)+10+(rand()%241)+10;
                    printf("\033[0;32m Player 1 without jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                else //without jumping
                {
                    h=tp[0]+(rand()%241)+10;
                    printf("\033[0;32m Player 1 with jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                pthread_mutex_unlock(&seeker_mutex2);



                pthread_mutex_lock(&seeker_mutex);
                while(flag ==0);
                printf("---------------------------------- Player 1 Thread Running now ! ----------------------------------------\n");
                printf(" Ball Height= %d , Seeker Height = %d\n",h,h1);
                pthread_mutex_unlock(&seeker_mutex);
                flag=0;
                if(h<=h1)
                {
                    pthread_mutex_lock(&seeker_mutex);
                    pCount[0]++;
                    printf("\033[0;35m Change Player1 to Seeker \n");
                    players[0]=0;
                    players[tSeeker]=1;
                    ball[0]=0;
                    ball[tSeeker]=1;

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);
                }
                else
                {
                    pthread_mutex_lock(&seeker_mutex);
                    players[0]=1;
                    players[toPlayer]=1;
                    ball[0]=0;
                    ball[toPlayer]=1;
                    printf("\033[0;35m Player %d catch the ball \n",toPlayer+1);

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);

                }
                printf("*********************************************************************************************************\n");
            }
            sleep(2);


        }
        else if (pthread_equal(p_thread, p_thread2)) ////////////////////////////////////////////////////////////// player 2
        {

            tSeeker= seekerInd();
            if (tSeeker==1)
            {
                printf("---------------------------------- Player 2 Thread Running now ! ----------------------------------------\n");
                pthread_mutex_lock(&seeker_mutex1);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h1=tp[1]+(rand()%50)+10;
                    printf("Seeker %d jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                else //without jumping
                {
                    h1=tp[1];
                    printf("Seeker %d without jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                pthread_mutex_unlock(&seeker_mutex1);
                printf("*********************************************************************************************************\n");
            }
            else if(ball[1] == 1) // ball with player2
            {
                printf("---------------------------------- Player 2 Thread Running now ! ----------------------------------------\n");
                int toPlayer = rand()%4;
                while(toPlayer == tSeeker || toPlayer == 1)
                {
                    toPlayer = rand()%4;
                }
                pthread_mutex_lock(&seeker_mutex2);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
//when player jump
                    h=tp[1]+(rand()%41)+10+(rand()%241)+10;
                    printf("\033[0;32m Player 2 without jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                else //without jumping
                {
                    h=tp[1]+(rand()%241)+10;
                    printf("\033[0;32m Player 2 jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                pthread_mutex_unlock(&seeker_mutex2);

                pthread_mutex_lock(&seeker_mutex);
                while(flag ==0);
                printf("---------------------------------- Player 2 Thread Running now ! ----------------------------------------\n");
                printf(" Ball Height= %d , Seeker Height = %d\n",h,h1);

                pthread_mutex_unlock(&seeker_mutex);
                flag=0;
                if(h<=h1)
                {
                    pthread_mutex_lock(&seeker_mutex);
                    pCount[1]++;
                    printf("\033[0;35m Change Player 2 to Seeker \n");
                    players[1]=0;
                    players[tSeeker]=1;
                    ball[1]=0;
                    ball[tSeeker]=1;

                    printStatus();
                    pthread_mutex_unlock(&seeker_mutex);
                }
                else
                {
                    pthread_mutex_lock(&seeker_mutex);
                    players[1]=1;
                    players[toPlayer]=1;
                    ball[1]=0;
                    ball[toPlayer]=1;
                    printf("\033[0;35m Player %d catch the ball \n",toPlayer+1);

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);

                }
                printf("*********************************************************************************************************\n");
            }
            sleep(2);


        }
        else if (pthread_equal(p_thread, p_thread3)) ////////////////////////////////////////////////////////////// player 3
        {

            tSeeker= seekerInd();
            if (tSeeker==2)
            {
                printf("---------------------------------- Player 3 Thread Running now ! ----------------------------------------\n");
                pthread_mutex_lock(&seeker_mutex1);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h1=tp[2]+(rand()%50)+10;
                    printf("Seeker %d jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                else //without jumping
                {
                    h1=tp[2];
                    printf("Seeker %d without jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                pthread_mutex_unlock(&seeker_mutex1);
                printf("*********************************************************************************************************\n");
            }
            else if(ball[2] == 1) // ball with player3
            {
                printf("---------------------------------- Player 3 Thread Running now ! ----------------------------------------\n");
                int toPlayer = rand()%4;
                while(toPlayer == tSeeker || toPlayer == 2)
                {
                    toPlayer = rand()%4;
                }
                pthread_mutex_lock(&seeker_mutex2);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h=tp[1]+(rand()%41)+10+(rand()%241)+10;
                    printf("\033[0;32m Player 3 without jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);;
                    printf("\033[0m");
                }
                else //without jumping
                {
                    h=tp[1]+(rand()%241)+10;
                    printf("\033[0;32m Player 3 jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                pthread_mutex_unlock(&seeker_mutex2);


                pthread_mutex_lock(&seeker_mutex);
                while(flag ==0);
                printf("---------------------------------- Player 3 Thread Running now ! ----------------------------------------\n");
                printf(" Ball Height= %d , Seeker Height = %d\n",h,h1);
                pthread_mutex_unlock(&seeker_mutex);
                flag=0;
                if(h<=h1)
                {
                    pthread_mutex_lock(&seeker_mutex);
                    pCount[2]++;
                    printf("\033[0;35m Change Player 3 to Seeker \n");
                    players[2]=0;
                    players[tSeeker]=1;
                    ball[2]=0;
                    ball[tSeeker]=1;

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);
                }
                else
                {
                    pthread_mutex_lock(&seeker_mutex);
                    players[2]=1;
                    players[toPlayer]=1;
                    ball[2]=0;
                    ball[toPlayer]=1;
                    printf("\033[0;35m Player %d catch the ball \n",toPlayer+1);

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);

                }
                printf("*********************************************************************************************************\n");
            }
            sleep(2);


        }
        else if (pthread_equal(p_thread, p_thread4)) ////////////////////////////////////////////////////////////// player 4
        {

            tSeeker= seekerInd();
            if (tSeeker==3)
            {
                printf("---------------------------------- Player 4 Thread Running now ! ----------------------------------------\n");
                pthread_mutex_lock(&seeker_mutex1);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h1=tp[3]+(rand()%50)+10;
                    printf("Seeker %d jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                else //without jumping
                {
                    h1=tp[3];
                    printf("Seeker %d without jumping with Height = %d \n",tSeeker+1,h1);
                    flag=1;
                }
                pthread_mutex_unlock(&seeker_mutex1);
                printf("*********************************************************************************************************\n");
            }
            else if(ball[3] == 1) // ball with player2
            {
                printf("---------------------------------- Player 4 Thread Running now ! ----------------------------------------\n");
                int toPlayer = rand()%4;
                while(toPlayer == tSeeker || toPlayer == 3)
                {
                    toPlayer = rand()%4;
                }
                pthread_mutex_lock(&seeker_mutex2);
                int jumpOrNot = rand()%2; // random jump
                if(jumpOrNot == 0) // jumping
                {
                    h=tp[3]+(rand()%41)+10+(rand()%241)+10;
                    printf("\033[0;32m Player 4 without jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                else //without jumping
                {
                    h=tp[3]+(rand()%241)+10;
                    printf("\033[0;32m Player 4 jumping with Height = %d and throwing the ball to Player %d\n",h,toPlayer+1);
                    printf("\033[0m");
                }
                pthread_mutex_unlock(&seeker_mutex2);


                pthread_mutex_lock(&seeker_mutex);
                while(flag ==0);
                printf("---------------------------------- Player 4 Thread Running now ! ----------------------------------------\n");
                printf(" Ball Height= %d , Seeker Height = %d\n",h,h1);
                pthread_mutex_unlock(&seeker_mutex);
                flag=0;
                if(h<=h1)
                {
                    pthread_mutex_lock(&seeker_mutex);
                    pCount[3]++;
                    printf("\033[0;35m Change Player 4 to Seeker \n");
                    players[3]=0;
                    players[tSeeker]=1;
                    ball[3]=0;
                    ball[tSeeker]=1;

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);
                }
                else
                {
                    pthread_mutex_lock(&seeker_mutex);
                    players[3]=1;
                    players[toPlayer]=1;
                    ball[3]=0;
                    ball[toPlayer]=1;
                    printf("\033[0;35m Player %d catch the ball \n",toPlayer+1);

                    printStatus();

                    pthread_mutex_unlock(&seeker_mutex);

                }
                printf("*********************************************************************************************************\n");
            }
            sleep(2);


        }
    }

    printf("\n<------------------------- END ------------------------->\n");

}


/* Driver code*/
int main(int argc, char* argv[])
{
    printf("================================= START =================================\n");
    /*Choos players and the ball-seeker tall in range [160cm-190cm] randomlly.*/
    srand(time(0));
    tp[0]=(rand()%30)+160;
    tp[1]=(rand()%30)+160;
    tp[2]=(rand()%30)+160;
    tp[3]=(rand()%30)+160;

    printStatus();

    /* Creating a new thread*/
    pthread_create(&p_thread1, NULL, game,NULL);
    pthread_create(&p_thread2, NULL, game,NULL);
    pthread_create(&p_thread3, NULL, game,NULL);
    pthread_create(&p_thread4, NULL, game,NULL);

    /* Waiting for the created thread to terminate*/
    pthread_join(p_thread1,NULL);
    pthread_join(p_thread2,NULL);
    pthread_join(p_thread3, NULL);
    pthread_join(p_thread4, NULL);
    return 0;
}

